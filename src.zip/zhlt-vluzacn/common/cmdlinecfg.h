#ifndef CMDLINECFG_H__
#define CMDLINECFG_H__
#include "cmdlib.h" //--vluzacn
extern void ParseParamFile (const int argc, char ** const argv, int &argcnew, char **&argvnew);
#endif
