#include "cmdlib.h"
#include "messages.h"
#include "log.h"
#include "hlassert.h"
#include "mathtypes.h"
#include "mathlib.h"
#include "win32fix.h"

const vec3_t    vec3_origin = { 0, 0, 0 };
